# car = {
# "brand": "Ford",
# "model": "Mustang",
# "year": 1964
# }
# print("value",car.values())
# print("keys",car.keys())
# print("items",car.items())

# arr=[
#   {
#   "name":"hari",
#   "age":24,
#   "height":5.8
#   },
#   {
#     "name":"ram",
#     "age":25,
#     "height":5.9
#   }
# ]
# for i in range(len(arr)):
#   print(arr[i]["name"])
#   print(arr[i]["age"])
#   print(arr[i]["height"])


day = 4
match day:
  case 1:
    print("Monday")
  case 2:
    print("Tuesday")
  case 3:
    print("Wednesday")
  case 4:
    print("Thursday")
  case 5:
    print("Friday")
  case 6:
    print("Saturday")
  case 7:
    print("Sunday")
